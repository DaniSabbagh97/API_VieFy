module.exports = {
  secretKey: 'tontinTimidin',
  port: 8080,
  tokenExpireSeconds: 604800,
  database: {
    username: "pfg_maesebit",
    password: "a1234a",
    db: "pfgmaesebit",
    host: "195.235.211.197",
  },
}
