modeule.exports = (database, sequelize) =>{
    const {DataTypes, Model} = sequelize
    class testResult extends Model{}

    testResult.init({
        

    })
}