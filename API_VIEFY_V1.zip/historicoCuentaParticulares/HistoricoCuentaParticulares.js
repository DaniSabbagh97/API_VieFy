module.exports = (HistoricoCuentaParticularesModel) => {

    class HistoricoCuentaParticulares {
        async get() {
          console.log('class get HistoricoCuentaParticulares')
          const hcp = await HistoricoCuentaParticularesModel.findAll()
          return hcp
        }

        async polla() {
          console.log('POLLA')
          
        }

        async insertarSalarioInicial(user, salarioAutonomo) {
          console.log('HOLAAAAAAAAAAAAAAAAAAAAAAAAA')
          
          await HistoricoCuentaParticularesModel.create({
            
            id_user: user.id_user,
            Saldo: salarioAutonomo,
            Gasto: 'NULL',
            Comentario: 'Generar saldo inicial',
            tipo_gasto: 'NULL',
            Hora: new Date().toISOString(), 
          })
          return true
          
        }
        
    }

    return new HistoricoCuentaParticulares()
}
